package model;

import java.time.LocalDate;
import java.util.ArrayList;

public class Habitacion {
    private int numHabitacion;
    private boolean libre;
    private double precio;
    private ArrayList<String> inventario;
    private int banos;
    private int numCamas;
    private ArrayList<String> mobiliarioBasico;
    private LocalDate fechaEntrada;
    private LocalDate fechaSalida;
    private String tipoCama;
    private TipoHabitacion tipoHabitacion;

    // Constructor
    public Habitacion(int numHabitacion, boolean libre, double precio, int banos, int numCamas, String tipoCama, TipoHabitacion tipoHabitacion) {
        this.numHabitacion = numHabitacion;
        this.libre = libre;
        this.precio = precio;
        this.banos = banos;
        this.numCamas = numCamas;
        this.fechaEntrada = null;
        this.fechaSalida = null;
        this.tipoCama= tipoCama;
        this.tipoHabitacion = tipoHabitacion;
        // Inicializar las listas
        this.inventario = new ArrayList<>();
        this.mobiliarioBasico = new ArrayList<>();
    }

    public int getNumHabitacion() {
        return numHabitacion;
    }

    public void setNumHabitacion(int numHabitacion) {
        this.numHabitacion = numHabitacion;
    }

    public boolean isLibre() {
        return libre;
    }

    public void setLibre(boolean libre) {
        this.libre = libre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public ArrayList<String> getInventario() {
        return inventario;
    }

    public void setInventario(ArrayList<String> inventario) {
        this.inventario = inventario;
    }

    public int getBanos() {
        return banos;
    }

    public void setBanos(int banos) {
        this.banos = banos;
    }

    public int getNumCamas() {
        return numCamas;
    }

    public void setNumCamas(int numCamas) {
        this.numCamas = numCamas;
    }


    public ArrayList<String> getMobiliarioBasico() {
        return mobiliarioBasico;
    }

    public void setMobiliarioBasico(ArrayList<String> mobiliarioBasico) {
        this.mobiliarioBasico = mobiliarioBasico;
    }

    public LocalDate getFechaEntrada() {
        return fechaEntrada;
    }

    public void setFechaEntrada(LocalDate fechaEntrada) {
        this.fechaEntrada = fechaEntrada;
    }

    public LocalDate getFechaSalida() {
        return fechaSalida;
    }

    public void setFechaSalida(LocalDate fechaSalida) {
        this.fechaSalida = fechaSalida;
    }

    public String getTipoCama() {
        return tipoCama;
    }

    public void setTipoCama(String tipoCama) {
        this.tipoCama = tipoCama;
    }

    public TipoHabitacion getTipoHabitacion() {
        return tipoHabitacion;
    }

    public void setTipoHabitacion(TipoHabitacion tipoHabitacion) {
        this.tipoHabitacion = tipoHabitacion;
    }
    
    
}
