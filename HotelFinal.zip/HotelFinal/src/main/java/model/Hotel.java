/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author yungk
 */
import controll.DBcontroller;
import DataBase.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Hotel {
    private List<Habitacion> habitaciones;

    public Hotel() {
        // Cargar habitaciones desde la base de datos al crear una instancia de Hotel
        this.habitaciones = cargarHabitacionesDesdeBaseDeDatos();
    }

    // Resto del código de Hotel...

    private List<Habitacion> cargarHabitacionesDesdeBaseDeDatos() {
        List<Habitacion> habitaciones = new ArrayList<>();
        Connection conexion = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            DBcontroller dbController = new Conexion();
            conexion = dbController.getConnection();
            
            String consulta = "SELECT * FROM habitaciones";
            statement = conexion.prepareStatement(consulta);
            resultSet = statement.executeQuery();

            while (resultSet.next()) {
                int numHabitacion = resultSet.getInt("numHabitacion");
                boolean libre = resultSet.getBoolean("libre");
                double precio = resultSet.getDouble("precio");
                int numCamas = resultSet.getInt("numCamas");
                int banos = resultSet.getInt("banos");
                String tipoCama = resultSet.getString("tipoCama");
                TipoHabitacion tipoHabitacion = TipoHabitacion.valueOf(resultSet.getString("tipoHabitacion"));

                Habitacion habitacion = new Habitacion(numHabitacion, libre, precio, numCamas, banos, tipoCama, tipoHabitacion);
                // Puedes agregar más atributos según la estructura de tu base de datos

                habitaciones.add(habitacion);
            }
        } catch (SQLException e) {
        } finally {
            Conexion miConexion = new Conexion();
            miConexion.cerrarConexion(conexion, statement, resultSet);
        }

        return habitaciones;
    }
    public void checkIn(Huesped huesped, TipoHabitacion tipoHabitacion, LocalDate fechaEntrada, LocalDate fechaSalida) {
       
        // Buscar una habitación disponible del tipo solicitado
        Habitacion habitacionDisponible = buscarHabitacionDisponible(tipoHabitacion);

        // Asignar la habitación al huésped si se encuentra disponible
        if (habitacionDisponible != null) {
            habitacionDisponible.setLibre(false);  // Marcar la habitación como no disponible
            habitacionDisponible.setFechaEntrada(fechaEntrada);
            habitacionDisponible.setFechaSalida(fechaSalida);
            
            // Puedes realizar otras operaciones relacionadas con el check-in aquí
            System.out.println("Check-in exitoso para " + huesped.getNombre() + " en la habitación " + habitacionDisponible.getNumHabitacion());
        } else {
            System.out.println("Lo siento, no hay habitaciones disponibles del tipo " + tipoHabitacion);
        }
    }

    public void checkOut(Habitacion habitacion) {
        // Realizar acciones relacionadas con el check-out
        // Por ejemplo, generar la lista de inventario, actualizar el estado de la habitación, etc.
        // ...

        // Marcar la habitación como disponible y limpiar las fechas de entrada y salida
        habitacion.setLibre(true);
        habitacion.setFechaEntrada(null);
        habitacion.setFechaSalida(null);

        // Puedes realizar otras operaciones relacionadas con el check-out aquí
        System.out.println("Check-out exitoso de la habitación " + habitacion.getNumHabitacion());
    }

    private Habitacion buscarHabitacionDisponible(TipoHabitacion tipoHabitacion) {
        // Lógica para buscar una habitación disponible del tipo solicitado
        for (Habitacion habitacion : habitaciones) {
            if (habitacion.isLibre() && habitacion.getTipoHabitacion() == tipoHabitacion) {
                return habitacion;
            }
        }
        return null;  // No se encontró ninguna habitación disponible del tipo solicitado
    }
}


