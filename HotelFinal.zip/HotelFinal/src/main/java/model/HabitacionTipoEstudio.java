package model;

import java.util.Arrays;

public class HabitacionTipoEstudio extends HabitacionSencilla {
    private boolean tieneSofaCama;

    // Constructor que inicializa los atributos específicos
    public HabitacionTipoEstudio(int numHabitacion, boolean libre, double precio, int banos, int numCamas, String tipoCama) {
        super(numHabitacion, libre, precio, 1, 1, "sofacama");
        this.tieneSofaCama = tieneSofaCama;

        // Actualizar el tipo de habitación
        this.setTipoHabitacion(TipoHabitacion.ESTUDIO);

        // Modificar mobiliario para incluir sofá cama
        this.getMobiliarioBasico().addAll(Arrays.asList("Sofá cama"));
    }

 
}
