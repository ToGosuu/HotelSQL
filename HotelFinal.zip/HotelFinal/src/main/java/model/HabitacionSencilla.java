/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.util.ArrayList;
import java.util.Arrays;
/**
 *
 * @author yungk
 */
public class HabitacionSencilla extends Habitacion {
    // Constructor que inicializa los atributos específicos
    public HabitacionSencilla(int numHabitacion, boolean libre, double precio, int banos, int numCamas, String tipoCama) {
        super(numHabitacion, libre, precio, 1, 1, "Individual", TipoHabitacion.SENCILLA);
        this.setMobiliarioBasico((ArrayList<String>) Arrays.asList("Cama individual", "Mesa", "Silla, Armario"));
        this.setInventario((ArrayList<String>) Arrays.asList("Televisión"));
    }
}
