/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Dao {
    
    private Connection connection;

    // Actualiza un objeto dentro de la base de datos ya sea para ingresar o retirar del sistema
    public static void updateData(Connection con, Habitacion habitacion, Huesped huesped) {
        // Nombre de la tabla
        String nombreTabla = "hoteldb";

        // Construir la consulta SQL UPDATE
        StringBuilder sql = new StringBuilder("UPDATE ");
        sql.append(nombreTabla).append(" SET ");
        sql.append("usuario = ?, ocupado = ?");

        // Agregar la cláusula WHERE usando la clave primaria
        sql.append(" WHERE numHabitacion = ?;");

        try {
            PreparedStatement preparedStatement = con.prepareStatement(sql.toString());

            // Establecer los valores de los parámetros
            preparedStatement.setString(1, huesped.getNombre());  // Aquí puedes ajustar según tus necesidades
            preparedStatement.setInt(2, 1);  // Ocupado
            preparedStatement.setInt(3, habitacion.getNumHabitacion());

            // Ejecutar la consulta
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Check-in exitoso. Datos actualizados en la base de datos.");
            } else {
                System.out.println("No se encontró la habitación para actualizar.");
            }
        } catch (SQLException e) {
        }
    }

    // Busca el objeto con cierto id dentro de la base de datos
    public static Habitacion findById(Connection con, int numHabitacion) {
        try {
            // Ejecuta la consulta SQL que devuelve objeto con la id requerida
            PreparedStatement preparedStatement = con.prepareStatement("SELECT * FROM habitaciones WHERE numHabitacion = ?");
            preparedStatement.setInt(1, numHabitacion);

            // Ejecutar la consulta
            ResultSet rs = preparedStatement.executeQuery();

            // Guarda todos los datos enviados de la base de datos y los guarda en un objeto
            if (rs.next()) {
                Habitacion habitacion = new Habitacion(
                        rs.getInt("numHabitacion"),
                        rs.getBoolean("libre"),
                        rs.getDouble("precio"),
                        rs.getInt("banos"),
                        rs.getInt("numCamas"),
                        rs.getString("tipoCama"),
                        TipoHabitacion.valueOf(rs.getString("tipoHabitacion")));
                habitacion.setFechaEntrada(rs.getDate("fechaEntrada").toLocalDate());
                habitacion.setFechaSalida(rs.getDate("fechaSalida").toLocalDate());
                // Otros atributos según la estructura de tu base de datos

                System.out.println(habitacion.toString());
                return habitacion;
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return null;
    }

    // Busca habitaciones disponibles del tipo especificado
    public static List<Habitacion> availableHabs(Connection con, String tipoHabitacion) {
        // Lista donde se guardarán las habitaciones disponibles
        List<Habitacion> listaHabs = new ArrayList<>();

        try {
            // Manda la query a la base de datos
            // Busca todas las habitaciones que tienen libre = true ya que son las que están disponibles
            PreparedStatement preparedStatement = con.prepareStatement("SELECT * FROM habitacion WHERE libre = true AND tipoHabitacion = ?");
            preparedStatement.setString(1, tipoHabitacion);

            // Ejecutar la consulta
            ResultSet rs = preparedStatement.executeQuery();

            // Recorre los objetos devueltos por la base de datos y los agrega a la lista
            while (rs.next()) {
                Habitacion habitacion = new Habitacion(
                        rs.getInt("numHabitacion"),
                        rs.getBoolean("libre"),
                        rs.getDouble("precio"),
                        rs.getInt("banos"),
                        rs.getInt("numCamas"),
                        rs.getString("tipoCama"),
                        TipoHabitacion.valueOf(rs.getString("tipoHabitacion")));
                habitacion.setFechaEntrada(rs.getDate("fechaEntrada").toLocalDate());
                habitacion.setFechaSalida(rs.getDate("fechaSalida").toLocalDate());
                // Otros atributos según la estructura de tu base de datos

                listaHabs.add(habitacion);
            }

            return listaHabs;

        } catch (SQLException e) {
            System.out.println(e);
        }
        return null;
    }
    
    public boolean connect() {
        try {
            // Establecer la conexión a la base de datos
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hoteldb", "root", "1234");
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public void disconnect() {
        try {
            // Cerrar la conexión a la base de datos
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void realizarCheckIn(int numeroHabitacion, String nombre, String apellido, String identificacion) {
        try {
            // Realizar el check-in: Insertar los datos en la base de datos
            String query = "UPDATE habitacion SET libre = 0, huespedNombre =  ? , huespedApellido = ? , huespedDocumentoIdentidad = ?  WHERE numHabitacion = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(4, numeroHabitacion);
                preparedStatement.setString(1, nombre);
                preparedStatement.setString(2, apellido);
                preparedStatement.setString(3, identificacion);

                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean realizarCheckOut(int numeroHabitacion) {
        try {
            // Realizar el check-out: Liberar la habitación en la base de datos
            String query = "UPDATE habitacion SET libre = 1, huespedNombre =  ' ' , huespedApellido = ' ' , huespedDocumentoIdentidad = ' '  WHERE numHabitacion = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, numeroHabitacion);

                int rowCount = preparedStatement.executeUpdate();

                // Verificar si se eliminó alguna fila (habitación existente y ocupada)
                return rowCount > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}

