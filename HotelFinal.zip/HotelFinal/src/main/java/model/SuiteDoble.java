/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;
import java.util.Arrays;

public class SuiteDoble extends Habitacion {
    private int numCamasDormitorioMatrimonial;
    private int numCamasDormitorioIndividual;
    private ArrayList<String> mobiliarioSalon;

    // Constructor que inicializa los atributos específicos
    public SuiteDoble(int numHabitacion, boolean libre, double precio, String tipoCamaDormitorioMatrimonial, String tipoCamaDormitorioIndividual) {
        super(numHabitacion, libre, precio, 2, 3, tipoCamaDormitorioMatrimonial, TipoHabitacion.SUITE_DOBLE);

        // Inicializar la lista de mobiliario del salón
        this.mobiliarioSalon = new ArrayList<>();

        // Asignar valores específicos a mobiliarioBasico, utensilios, e inventario
        this.setMobiliarioBasico((ArrayList<String>) Arrays.asList("Cama matrimonial", "Cama individual", "Cama individual", "Mesa", "Silla"));
        this.setInventario((ArrayList<String>) Arrays.asList("Televisión", "Teléfono"));

        // Asignar valores específicos a mobiliarioSalon y numCamasDormitorio
        this.mobiliarioSalon.addAll(Arrays.asList("Sofá", "Mesita de centro", "Lámpara"));
        this.numCamasDormitorioMatrimonial = 1; // Una cama matrimonial en el dormitorio principal
        this.numCamasDormitorioIndividual = 2; // Dos camas individuales en el otro dormitorio
    }

    // Getters y setters específicos de SuiteDoble

    public int getNumCamasDormitorioMatrimonial() {
        return numCamasDormitorioMatrimonial;
    }

    public int getNumCamasDormitorioIndividual() {
        return numCamasDormitorioIndividual;
    }

    public ArrayList<String> getMobiliarioSalon() {
        return mobiliarioSalon;
    }
}
