/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author yungk
 */
import java.util.ArrayList;
import java.util.Arrays;

public class SuitePresidencial extends Habitacion {
    private int numDormitorios;
    private ArrayList<String> mobiliarioSalaRecibo;

    // Constructor que inicializa los atributos específicos
    public SuitePresidencial(int numHabitacion, boolean libre, double precio, int numDormitorios) {
        super(numHabitacion, libre, precio, numDormitorios, numDormitorios, "Matrimonial doble", TipoHabitacion.SUITE_PRESIDENCIAL);

        this.numDormitorios = numDormitorios;
        this.mobiliarioSalaRecibo = new ArrayList<>();
        // Asignar valores específicos a mobiliarioBasico, utensilios, e inventario
        this.setMobiliarioBasico((ArrayList<String>) Arrays.asList("Cama matrimonial doble", "Mesa", "Silla"));
        this.setInventario((ArrayList<String>) Arrays.asList("Televisión", "Teléfono"));
        this.mobiliarioSalaRecibo.addAll(Arrays.asList("Alfombra", "Lámpara", "Florero", "Cuadro", "Escultura"));
    }

    // Getters y setters específicos de SuitePresidencial

    public int getNumDormitorios() {
        return numDormitorios;
    }

    public ArrayList<String> getMobiliarioSalaRecibo() {
        return mobiliarioSalaRecibo;
    }


}

