/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.util.ArrayList;
import java.util.Arrays;
/**
 *
 * @author yungk
 */


public class SuiteJunior extends Habitacion {
    private ArrayList<String> mobiliarioSalon;
    private int numCamasDormitorio;

    // Constructor que inicializa los atributos específicos
    public SuiteJunior(int numHabitacion, boolean libre, double precio, String tipoCamaDormitorio, int numCamasDormitorio) {
        super(numHabitacion, libre, precio, 1, 1, tipoCamaDormitorio, TipoHabitacion.SUITE_JUNIOR);

        // Inicializar la lista de mobiliario del salón
        this.mobiliarioSalon = new ArrayList<>();

        // Asignar valores específicos a mobiliarioBasico, utensilios, e inventario
        this.setMobiliarioBasico((ArrayList<String>) Arrays.asList("Cama individual", "Cama individual", "Mesa", "Silla"));
        this.setInventario((ArrayList<String>) Arrays.asList("Televisión", "Teléfono"));

        // Asignar valores específicos a mobiliarioSalon y numCamasDormitorio
        this.mobiliarioSalon.addAll(Arrays.asList("Sofá", "Mesita de centro", "Lámpara"));
        this.numCamasDormitorio = numCamasDormitorio;
    }

    // Getters y setters específicos de SuiteJunior

    public ArrayList<String> getMobiliarioSalon() {
        return mobiliarioSalon;
    }

    public int getNumCamasDormitorio() {
        return numCamasDormitorio;
    }
}
