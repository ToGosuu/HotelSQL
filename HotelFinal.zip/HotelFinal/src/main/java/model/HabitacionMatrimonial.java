/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author yungk
 */
public class HabitacionMatrimonial extends Habitacion {
    // Nuevo atributo específico para el tipo de cama matrimonial
    private String tipoCamaMatrimonial;

    // Constructor que inicializa los atributos específicos
    public HabitacionMatrimonial(int numHabitacion, boolean libre, double precio, String tipoCamaMatrimonial) {
        super(numHabitacion, libre, precio, 1, 2, "Matrimonial", TipoHabitacion.MATRIMONIAL);  // Por ejemplo, 1 baño y 2 camas individuales

        // Asignar valores específicos a mobiliarioBasico, utensilios, e inventario
        this.setMobiliarioBasico((ArrayList<String>) Arrays.asList("Cama matrimonial", "Mesa", "Silla"));
        this.setInventario((ArrayList<String>) Arrays.asList("Televisión", "Teléfono"));

        // Asignar el tipo de cama matrimonial
        this.tipoCamaMatrimonial = tipoCamaMatrimonial;
    }

    // Getter y Setter para el tipo de cama matrimonial
    public String getTipoCamaMatrimonial() {
        return tipoCamaMatrimonial;
    }

    public void setTipoCamaMatrimonial(String tipoCamaMatrimonial) {
        this.tipoCamaMatrimonial = tipoCamaMatrimonial;
    }
}
