
package model;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfWriter;
import DataBase.Conexion;
import java.io.FileOutputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletResponse;


public class PdfGenerator {


    public static void crearBlogDesdeBaseDeDatos(int numHabitacion) {
    // Obtener datos de la base de datos
    String titulo = "Reserva Exitosa";
    String texto = "";

    // Establecer conexión a la base de datos
    Conexion conexion = new Conexion();
    try {
        String query = "SELECT numHabitacion, precio, banos, numCamas, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario FROM habitacion WHERE numHabitacion = ?";
        try (PreparedStatement preparedStatement = conexion.getConnection().prepareStatement(query)) {
            preparedStatement.setInt(1, numHabitacion);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    // Obtener información de la habitación
                    int numCamas = resultSet.getInt("numCamas");
                    String tipoCama = resultSet.getString("tipoCama");
                    String huespedNombre = resultSet.getString("huespedNombre");
                    String huespedApellido = resultSet.getString("huespedApellido");
                    String huespedDocumentoIdentidad = resultSet.getString("huespedDocumentoIdentidad");
                    String mobiliarioBasico = resultSet.getString("mobiliarioBasico");
                    String inventario = resultSet.getString("inventario");

                    // Construir el texto para el PDF
                    texto = "Habitacion numero " + numHabitacion + " reservada por " + huespedNombre + " " + huespedApellido + " con CC: " + huespedDocumentoIdentidad
                            + "\nDetalles de la habitacion: numero de camas y tipo " + numCamas + " " + tipoCama
                            + "\nmobiliario e inventario: " + mobiliarioBasico+ " " + inventario;
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } 

    // Crear el PDF con los datos de la base de datos
    crearBlog(titulo, texto);
}

public static void crearBlog(String titulo, String texto) {
    try {
        Document doc = new Document();
        PdfWriter.getInstance(doc, new FileOutputStream("post.pdf"));
        doc.open();

        Font titleFont = FontFactory.getFont(BaseFont.TIMES_BOLD, 21, BaseColor.RED);
        Font bodyFont = FontFactory.getFont(BaseFont.HELVETICA, 12, BaseColor.BLACK);

        Paragraph title = new Paragraph(titulo, titleFont);
        Paragraph body = new Paragraph(texto, bodyFont);

        doc.add(title);
        doc.add(body);

        doc.close();

    } catch (DocumentException | java.io.FileNotFoundException e) {
        e.printStackTrace();
    }
 }

    public static void descargarPDF(String filePath) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        ExternalContext externalContext = facesContext.getExternalContext();
        HttpServletResponse response = (HttpServletResponse) externalContext.getResponse();

        response.reset();
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=\"" + filePath + "\"");

        try (OutputStream outputStream = response.getOutputStream();
             FileInputStream fileInputStream = new FileInputStream(new File(filePath))) {

            byte[] buffer = new byte[1024];
            int length;

            while ((length = fileInputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }

            outputStream.flush();
            facesContext.responseComplete();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}