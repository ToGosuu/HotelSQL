/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.util.ArrayList;
import java.util.Arrays;
/**
 *
 * @author yungk
 */

public class HabitacionDoble extends Habitacion {
    // Constructor que inicializa los atributos específicos
    public HabitacionDoble(int numHabitacion, boolean libre, double precio) {
        super(numHabitacion, libre, precio, 1, 1, "Individual", TipoHabitacion.DOBLE);  // Por ejemplo, 1 baño y 2 camas individuales

        // Asignar valores específicos a mobiliarioBasico, utensilios, e inventario
        this.setMobiliarioBasico((ArrayList<String>) Arrays.asList("Cama individual", "Cama individual", "Mesa", "Silla"));
        this.setInventario((ArrayList<String>) Arrays.asList("Televisión", "Teléfono"));
    }
}

