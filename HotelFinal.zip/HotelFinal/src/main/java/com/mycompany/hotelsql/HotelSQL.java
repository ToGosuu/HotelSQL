package com.mycompany.hotelsql;

import model.Dao;
import model.PdfGenerator;
import java.util.Scanner;

public class HotelSQL {
    public static void main(String[] args) {
        // Crear un objeto de la clase Dao para manejar la conexión y las operaciones con la base de datos
        Dao dao = new Dao();

        // Verificar si la conexión es exitosa
        if (dao.connect()) {
            System.out.println("Conexión exitosa a la base de datos");

            // Realizar operaciones de check-in y check-out
            try ( // Crear un scanner para obtener la entrada del usuario
                    Scanner scanner = new Scanner(System.in)) {
                // Realizar operaciones de check-in y check-out
                realizarCheckIn(scanner, dao);
                realizarCheckOut(scanner, dao);
                // Cerrar el scanner
            }
            
            
            // Cerrar la conexión a la base de datos
            dao.disconnect();
        } else {
            System.out.println("Error al conectar a la base de datos");
        }
    }

    private static void realizarCheckIn(Scanner scanner, Dao dao) {
        System.out.println("===== CHECK-IN =====");

        // Obtener información del usuario para check-in
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Apellido: ");
        String apellido = scanner.nextLine();

        System.out.print("Número de habitación: ");
        int numeroHabitacion = scanner.nextInt();
        scanner.nextLine(); // Consumir la nueva línea después de nextInt

        System.out.print("Identificación: ");
        String identificacion = scanner.nextLine();

        // Realizar check-in y actualizar la base de datos
        dao.realizarCheckIn(numeroHabitacion, nombre, apellido, identificacion);
        
        PdfGenerator.crearBlogDesdeBaseDeDatos(numeroHabitacion);

        System.out.println("Check-in exitoso");
    }

    private static void realizarCheckOut(Scanner scanner, Dao dao) {
        System.out.println("===== CHECK-OUT =====");

        // Obtener información del usuario para check-out
        System.out.print("Número de habitación a liberar: ");
        int numeroHabitacionCheckOut = scanner.nextInt();

        // Realizar check-out y liberar la habitación en la base de datos
        boolean checkOutExitoso = dao.realizarCheckOut(numeroHabitacionCheckOut);

        if (checkOutExitoso) {
            System.out.println("Check-out exitoso. La habitación ha sido liberada.");
        } else {
            System.out.println("La habitación no existe o está ocupada.");
        }
    }
    
    
}