/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DataBase;
import controll.DBcontroller;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author dilan.holguin
 */
public class Conexion implements DBcontroller {
    
    // Query para crear la base de datos
    public static String queryCreateDB = "CREATE DATABASE IF NOT EXISTS hoteldb";

    // Query para crear la tabla Habitacion
   public static String queryCreateTableHabitacion = "CREATE TABLE IF NOT EXISTS Habitacion (" +
            "numHabitacion INT PRIMARY KEY," +
            "libre BOOLEAN," +
            "precio DOUBLE NOT NULL DEFAULT 0.0," +
            "banos INT NOT NULL DEFAULT 0," +
            "numCamas INT NOT NULL DEFAULT 0," +
            "fechaEntrada DATE," +
            "fechaSalida DATE," +
            "tipoCama VARCHAR(50) NOT NULL DEFAULT ''," +
            "tipoHabitacion VARCHAR(50)," +
            "huespedNombre VARCHAR(50)," +
            "huespedApellido VARCHAR(50)," +
            "huespedDocumentoIdentidad VARCHAR(50)," +
            "mobiliarioBasico JSON," +
            "inventario JSON" +
            ")";

    
    // Query para agregar datos a la tabla Habitacion
    public static String[] queryInsertData = {
    //INSERTS HABITACIONES SENCILLAS
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (101, 1, 20, 1, 1, null, null, 'individual', 'Sencilla', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (102, 1, 20, 1, 1, null, null, 'individual', 'Sencilla', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (103, 1, 20, 1, 1, null, null, 'individual', 'Sencilla', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (104, 1, 20, 1, 1, null, null, 'individual', 'Sencilla', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (105, 1, 20, 1, 1, null, null, 'individual', 'Sencilla', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (106, 1, 20, 1, 1, null, null, 'individual', 'Sencilla', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (107, 1, 20, 1, 1, null, null, 'individual', 'Sencilla', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (108, 1, 20, 1, 1, null, null, 'individual', 'Sencilla', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (109, 1, 20, 1, 1, null, null, 'individual', 'Sencilla', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (110, 1, 20, 1, 1, null, null, 'individual', 'Sencilla', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    //INSERT HABITACIONES DOBLES
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (201, 1, 40, 1, 2, null, null, 'individual X2', 'Doble', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (202, 1, 40, 1, 2, null, null, 'individual X2', 'Doble', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (203, 1, 40, 1, 2, null, null, 'individual X2', 'Doble', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (204, 1, 40, 1, 2, null, null, 'individual X2', 'Doble', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (205, 1, 40, 1, 2, null, null, 'individual X2', 'Doble', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (206, 1, 40, 1, 2, null, null, 'individual X2', 'Doble', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (207, 1, 40, 1, 2, null, null, 'individual X2', 'Doble', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (208, 1, 40, 1, 2, null, null, 'individual X2', 'Doble', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (209, 1, 40, 1, 2, null, null, 'individual X2', 'Doble', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (210, 1, 40, 1, 2, null, null, 'individual X2', 'Doble', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    //INSERT HABITACIONES MATRIMONIALES
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (301, 1, 70, 1, 1, null, null, 'doble', 'Matrimonial', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (302, 1, 70, 1, 1, null, null, 'queen', 'Matrimonial', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (303, 1, 70, 1, 1, null, null, 'king', 'Matrimonial', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (304, 1, 70, 1, 1, null, null, 'doble', 'Matrimonial', '', '', '', '[\"silla\",\"mesa\"]', '[\"toallas\",\"jabon\"]')",
    //INSERT HABITACION TIPO ESTUDIO
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (305, 1, 30, 1, 1, null, null, 'sofacama', 'Estudio', '', '', '', '[\"silla\",\"escritorio\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (306, 1, 30, 1, 1, null, null, 'sofacama', 'Estudio', '', '', '', '[\"silla\",\"escritorio\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (307, 1, 30, 1, 1, null, null, 'sofacama', 'Estudio', '', '', '', '[\"silla\",\"escritorio\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (308, 1, 30, 1, 1, null, null, 'sofacama', 'Estudio', '', '', '', '[\"silla\",\"escritorio\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (309, 1, 30, 1, 1, null, null, 'sofacama', 'Estudio', '', '', '', '[\"silla\",\"escritorio\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (310, 1, 30, 1, 1, null, null, 'sofacama', 'Estudio', '', '', '', '[\"silla\",\"escritorio\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (311, 1, 30, 1, 1, null, null, 'sofacama', 'Estudio', '', '', '', '[\"silla\",\"escritorio\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (312, 1, 30, 1, 1, null, null, 'sofacama', 'Estudio', '', '', '', '[\"silla\",\"escritorio\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (313, 1, 30, 1, 1, null, null, 'sofacama', 'Estudio', '', '', '', '[\"silla\",\"escritorio\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (314, 1, 30, 1, 1, null, null, 'sofacama', 'Estudio', '', '', '', '[\"silla\",\"escritorio\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (315, 1, 30, 1, 1, null, null, 'sofacama', 'Estudio', '', '', '', '[\"silla\",\"escritorio\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (316, 1, 30, 1, 1, null, null, 'sofacama', 'Estudio', '', '', '', '[\"silla\",\"escritorio\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (317, 1, 30, 1, 1, null, null, 'sofacama', 'Estudio', '', '', '', '[\"silla\",\"escritorio\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (318, 1, 30, 1, 1, null, null, 'sofacama', 'Estudio', '', '', '', '[\"silla\",\"escritorio\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (319, 1, 30, 1, 1, null, null, 'sofacama', 'Estudio', '', '', '', '[\"silla\",\"escritorio\"]', '[\"toallas\",\"jabon\"]')",
    //INSERT HABITACION SUITE JUNIOR
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (401, 1, 100, 2, 2, null, null, 'matrimonial', 'Suite Junior', '', '', '', '[\"silla\",\"mesa\",\"salon de estar\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (402, 1, 100, 2, 2, null, null, 'individual x2', 'Suite Junior', '', '', '', '[\"silla\",\"mesa\",\"salon de estar\"]', '[\"toallas\",\"jabon\"]')",
    //INSERT HABITACION SUITE DOBLE
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (403, 1, 120, 2, 3, null, null, 'king, individual x2', 'Suite Doble', '', '', '', '[\"silla\",\"mesa\",\"salon de estar\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (404, 1, 120, 2, 3, null, null, 'queen, individual x2', 'Suite Doble', '', '', '', '[\"silla\",\"mesa\",\"salon de estar\"]', '[\"toallas\",\"jabon\"]')",
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (405, 1, 120, 2, 3, null, null, 'doble, individual x2', 'Suite Doble', '', '', '', '[\"silla\",\"mesa\",\"salon de estar\"]', '[\"toallas\",\"jabon\"]')",
    //INSERT SUITE PRESIDENCIAL
    "INSERT INTO Habitacion (numHabitacion, libre, precio, banos, numCamas, fechaEntrada, fechaSalida, tipoCama, tipoHabitacion, huespedNombre, huespedApellido, huespedDocumentoIdentidad, mobiliarioBasico, inventario) VALUES (500, 1, 150, 3, 3, null, null, 'king, individual x2', 'Suite Presidencial', '', '', '', '[\"silla\",\"mesa\",\"salon de estar\",\"sofa lujoso\"]', '[\"toallas\",\"jabon\"]')"
    };


    // Inicia la conexión con la base de datos
    @Override
    public Connection getConnection() {
        Connection con = null;
        String sURL = "jdbc:mysql://localhost:3306/hoteldb";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(sURL, "root", "1234");
        } catch (ClassNotFoundException | SQLException e) {
            try {
                throw new SQLException("Error en la conexión", e);
            } catch (SQLException ex) {
                Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return con;
    }
    
        public void insertData(Connection con) {
    try {
        // Crear una declaración SQL
        Statement statement = con.createStatement();

        // Insertar valores predefinidos en la tabla Habitacion
        for (String insertStatement : queryInsertData) {
            statement.executeUpdate(insertStatement);
        }

        System.out.println("Valores predefinidos insertados en la tabla Registro");
        } catch (SQLException e) {
        }
    }
        
     public void insertDataHabitacion(Connection con) {
    try {
        // Crear una declaración SQL
        Statement statement = con.createStatement();

        // Insertar valores predefinidos en la tabla Habitacion
        for (String insertStatement : queryInsertData) {
            statement.executeUpdate(insertStatement);
        }

        System.out.println("Valores predefinidos insertados en la tabla Habitacion");
     } catch (SQLException e) {
     }
    }
    
    // Ejecuta todas las consultas SQL que creamos como cadenas anteriormente
    @Override
    public void createDatabase(Connection con) {
        try {
            // Crear una declaración SQL
            Statement statement = con.createStatement();

            // Verificar si la base de datos ya existe
            ResultSet rs = statement.executeQuery("SHOW DATABASES LIKE 'hoteldb';");

            if (!rs.next()) {
                // La base de datos no existe, entonces la creamos
                statement.executeUpdate(queryCreateDB);
                statement.executeUpdate("USE hoteldb;");

                // Crear la tabla Habitacion
                statement.executeUpdate(queryCreateTableHabitacion);
                // Insertar valores predefinidos en la tabla Habitacion
                insertDataHabitacion(con);
                
                System.out.println("Base de datos y tablas creadas");
            } else {
                System.out.println("La base de datos ya existe");
            }
        } catch (SQLException e) {
        }
    }

     public void cerrarConexion(Connection conexion, PreparedStatement statement, ResultSet resultSet) {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (conexion != null) {
                conexion.close();
            }
        } catch (SQLException e) {
        }
    }

    public void cerrarConexion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
