/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package controll;
import java.sql.Connection;

/**
 *
 * @author dilan.holguin
 */
public interface DBcontroller {
    public Connection getConnection();
    public void createDatabase(Connection con);
}
